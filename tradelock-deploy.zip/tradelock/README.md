# TradeLock — déploiement sur ton VM Oracle Cloud

Ce paquet contient tout ce qu'il faut. Tu n'as **rien à coder** — juste à suivre les
étapes ci-dessous sur ton VM. Une fois fait, tu ouvres l'URL depuis n'importe quel
appareil et c'est tout : pas besoin de retourner sur le VM.

## Ce que tu vas obtenir

- `http://<IP_DU_VM>:8080/<secret>/` → dashboard des alertes (ajout / liste avec
  compte à rebours en direct / suppression), auto-synchronisé toutes les 5 min
- `http://<IP_DU_VM>:8080/<secret>/static/skingap.html` → ton rapport SkinGap,
  régénéré automatiquement toutes les heures, avec un lien direct depuis le dashboard
- Une notif push ntfy 1h avant la fin de chaque trade lock (avec le prix min actuel
  et un bouton "Ouvrir sur Skinport"), puis une seconde notif au moment exact

`<secret>` est une longue chaîne aléatoire que tu vas générer à l'étape 3 — c'est ce
qui protège ton dashboard (pas de login, mais personne ne devine une URL avec un
token de 32 caractères hexadécimaux).

---

## Étape 1 — Connexion au VM

```bash
ssh <ton_user>@<IP_DU_VM>
```

## Étape 2 — Java 17 (si pas déjà installé)

```bash
sudo apt update
sudo apt install -y openjdk-17-jdk-headless
java -version   # doit afficher 17 ou plus
```

## Étape 3 — Copier les fichiers sur le VM

Depuis ta machine (pas le VM), avec le dossier `tradelock/` que je t'ai donné :

```bash
scp -r tradelock <ton_user>@<IP_DU_VM>:/tmp/tradelock
```

Puis sur le VM :

```bash
sudo mkdir -p /opt/tradelock
sudo mv /tmp/tradelock/* /opt/tradelock/
sudo useradd --system --home /opt/tradelock --shell /usr/sbin/nologin tradelock
sudo chown -R tradelock:tradelock /opt/tradelock
```

## Étape 4 — Configuration (`config.properties`)

```bash
cd /opt/tradelock/server
sudo -u tradelock cp config.properties.example config.properties
```

Génère les deux valeurs secrètes :

```bash
openssl rand -hex 16   # → pour path.secret
openssl rand -hex 12   # → pour ntfy.topic
```

Édite le fichier :

```bash
sudo -u tradelock nano config.properties
```

Remplace `path.secret` et `ntfy.topic` par les valeurs générées. Tu peux aussi
ajuster `reminder.minutes.before` (60 par défaut).

**Note bien le `path.secret`** — c'est le morceau d'URL que tu vas bookmarker.

## Étape 5 — Installer l'appli ntfy sur ton téléphone

1. Installe l'app **ntfy** (Play Store / App Store — gratuite, pas de compte requis)
2. Dans l'app, ajoute un abonnement au topic que tu as généré (le `ntfy.topic` de
   l'étape 4) — même nom exact, en tapant le topic manuellement ou via un QR code
   généré sur https://ntfy.sh/<ton_topic> (page web, bouton "Subscribe")
3. Vérifie que les notifs de l'app sont autorisées dans les réglages de ton téléphone
   (et idéalement que l'app n'est pas soumise à une optimisation batterie agressive,
   pour recevoir les notifs même téléphone éteint/en veille — voir la doc ntfy pour
   ton modèle si besoin : https://docs.ntfy.sh/subscribe/phone/)

## Étape 6 — Ouvrir le port sur Oracle Cloud

Le VM Oracle a **deux pare-feux à ouvrir** (souvent oublié — cause n°1 de "ça ne
marche pas") :

**a) Security List / Network Security Group (console Oracle Cloud)**
- Va dans la console Oracle Cloud → ton VCN → Security Lists (ou NSG rattaché au VM)
- Ajoute une règle Ingress : Source `0.0.0.0/0`, protocole TCP, port de destination
  `8080`

**b) Pare-feu local du VM (iptables/firewalld selon la distro Oracle Linux/Ubuntu)**

Sur Ubuntu (souvent déjà ouvert par défaut, sinon) :
```bash
sudo iptables -I INPUT -p tcp --dport 8080 -j ACCEPT
sudo netfilter-persistent save 2>/dev/null || true
```

Sur Oracle Linux (firewalld) :
```bash
sudo firewall-cmd --permanent --add-port=8080/tcp
sudo firewall-cmd --reload
```

## Étape 7 — Installer les services systemd

```bash
sudo cp /opt/tradelock/systemd/tradelock.service /etc/systemd/system/
sudo cp /opt/tradelock/systemd/skingap-report.service /etc/systemd/system/
sudo cp /opt/tradelock/systemd/skingap-report.timer /etc/systemd/system/

sudo systemctl daemon-reload
sudo systemctl enable --now tradelock.service
sudo systemctl enable --now skingap-report.timer
```

Le premier lancement de `skingap-report.timer` se fait 2 minutes après le boot (voir
`OnBootSec=2min` dans le fichier `.timer`) ; pour générer le rapport tout de suite
sans attendre :

```bash
sudo systemctl start skingap-report.service
```

## Étape 8 — Vérifier que tout tourne

```bash
sudo systemctl status tradelock.service
sudo systemctl status skingap-report.timer
sudo journalctl -u tradelock.service -f      # logs en direct, Ctrl+C pour quitter
```

Tu dois voir dans les logs :
```
TradeLockServer démarré sur le port 8080
Dashboard : http://<IP_DU_VM>:8080/<secret>/
```

## Étape 9 — Bookmarker l'URL

Depuis ton téléphone/ordi, ouvre :

```
http://<IP_DU_VM>:8080/<le_path.secret_de_l'étape_4>/
```

Ajoute-la aux favoris de Chrome. C'est la seule URL dont tu auras besoin désormais —
elle contient le lien vers `skingap.html` en haut à droite.

---

## Test de bout en bout

1. Ajoute une alerte test avec une date de fin dans 2 minutes
2. Attends la notif de rappel (normalement à -60min, donc tu ne la verras pas pour
   un test aussi court — c'est normal) puis la notif finale à l'échéance
3. Vérifie sur ton téléphone que la notif ntfy arrive bien, avec le bouton "Ouvrir
   sur Skinport"
4. Supprime l'alerte test depuis le dashboard

## Maintenance

- **Logs** : `sudo journalctl -u tradelock.service -f`
- **Redémarrer le service** : `sudo systemctl restart tradelock.service`
- **Sauvegarde des alertes** : le fichier `/opt/tradelock/server/alerts.json`
  contient tout — tu peux le copier ailleurs si tu veux une sauvegarde
- **Mettre à jour le code** : remplace `TradeLockServer.java` sur le VM puis
  `sudo systemctl restart tradelock.service` (pas de compilation manuelle requise,
  `java` recompile le `.java` à chaque lancement)

## Limites connues / choix assumés

- **Pas de HTTPS** : le trafic entre ton téléphone et le VM n'est pas chiffré. Pour
  un usage strictement personnel avec un token dans l'URL, c'est le compromis
  accepté dans la spec (pas de gros setup nginx+certbot pour ça). Si tu veux du
  HTTPS plus tard (ex: via un nom de domaine + Let's Encrypt), dis-le moi, c'est
  ajoutable.
- **Prix dans la notif** = prix minimum actuellement listé sur Skinport (annonces
  disponibles), pas le calcul complet de `SkinGap.java` (médiane pondérée des
  ventes réelles). Simplification volontaire pour ne pas télécharger tout le
  catalogue Skinport à chaque notif avec toute la logique de gap — si tu veux la
  logique complète ici aussi, je peux la porter.
- **Le nom du skin doit être exact** (celui de Skinport, ex.
  `AK-47 | Redline (Field-Tested)`) pour que le prix et le lien direct fonctionnent
  correctement — sinon la notif part quand même mais sans prix.
